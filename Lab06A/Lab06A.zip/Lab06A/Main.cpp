#include <iostream>
#include <string>
#include "UnderGraduate.h"
#include "Student.h"
#include "Date.h"

using namespace std;

int main() {
	cout << "It gets here" << endl;
	Student a("Bread",Date(11, 11, 1997));
	cout << "But not here" << endl;
	UnderGraduate b("Julia", Date(25, 10, 2006));
	return 0;
}